﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingCardsA3
{
    //public class Player
    //{
    //    public string Name { get; set; }
    //    public string Team { get; set; }
    //    public Image Photo { get; set; }
    //    public string Position { get; set; }
    //    public int Goals { get; set; }
    //    public int Assists { get; set; }
    //    public int MatchesPlayed { get; set; }
    //    public int YellowCards { get; set; }

    //    public Player(string name, string team, Image photo, string position, int goals, int assists, int matchesPlayed, int yellowCards)
    //    {
    //        Name = name;
    //        Team = team;
    //        Photo = photo;
    //        Position = position;
    //        Goals = goals;
    //        Assists = assists;
    //        MatchesPlayed = matchesPlayed;
    //        YellowCards = yellowCards;
    //    }
    //}
}
            

    //    static void Main(string[] args)
    //    {
    //        // Dataset
    //        List<Player> players = new List<Player>
    //        {
    //        new Player { Name = "Lionel Messi", Team = "Paris FC", PhotoUrl = "messi.jpg", Position = "Forward", Goals = 15, Assists = 10, MatchesPlayed = 20, YellowCards = 2 },
    //        new Player { Name = "Kylian Mbappé", Team = "Paris FC", PhotoUrl = "mbappe.jpg", Position = "Forward", Goals = 18, Assists = 8, MatchesPlayed = 22, YellowCards = 3 },
    //        new Player { Name = "Sergio Ramos", Team = "Paris FC", PhotoUrl = "ramos.jpg", Position = "Defender", Goals = 2, Assists = 1, MatchesPlayed = 18, YellowCards = 5 },
    //        new Player { Name = "Erling Haaland", Team = "Manchester Strikers", PhotoUrl = "haaland.jpg", Position = "Forward", Goals = 20, Assists = 6, MatchesPlayed = 21, YellowCards = 1 },
    //        new Player { Name = "Kevin De Bruyne", Team = "Manchester Strikers", PhotoUrl = "debruyne.jpg", Position = "Midfielder", Goals = 5, Assists = 15, MatchesPlayed = 19, YellowCards = 2 },
    //        new Player { Name = "Ruben Dias", Team = "Manchester Strikers", PhotoUrl = "dias.jpg", Position = "Defender", Goals = 1, Assists = 0, MatchesPlayed = 20, YellowCards = 4 },
    //        new Player { Name = "Cristiano Ronaldo", Team = "Juventus Legends", PhotoUrl = "ronaldo.jpg", Position = "Forward", Goals = 12, Assists = 4, MatchesPlayed = 18, YellowCards = 2 },
    //        new Player { Name = "Paulo Dybala", Team = "Juventus Legends", PhotoUrl = "dybala.jpg", Position = "Forward", Goals = 7, Assists = 6, MatchesPlayed = 19, YellowCards = 1 },
    //        new Player { Name = "Leonardo Bonucci", Team = "Juventus Legends", PhotoUrl = "bonucci.jpg", Position = "Defender", Goals = 3, Assists = 1, MatchesPlayed = 21, YellowCards = 5 },
    //        new Player { Name = "Wojciech Szczesny", Team = "Juventus Legends", PhotoUrl = "szczesny.jpg",Position = "Goalkeeper", Goals = 0, Assists = 0, MatchesPlayed = 20, YellowCards = 0 }
    //        };
    //        // Example LINQ Queries
    //        var topScorers = players.Where(p => p.Goals > 10).OrderByDescending(p => p.Goals);
    //        var teamParisFC = players.Where(p => p.Team == "Paris FC");
    //        var forwards = players.Where(p => p.Position == "Forward");

    //        // Displaying data

    //        Console.WriteLine("Top Scorers:");
    //        foreach (var player in topScorers)
    //        {
    //            Console.WriteLine($"{player.Name} - {player.Team} - Goals: {player.Goals}");
    //        }

    //        Console.WriteLine("\nParis FC Players:");
    //        foreach (var player in teamParisFC)
    //        {
    //            Console.WriteLine($"{player.Name} - Position: {player.Position}");
    //        }

    //        Console.WriteLine("\nAll Forwards:");
    //        foreach (var player in forwards)
    //        {
    //            Console.WriteLine($"{player.Name} - {player.Team}");
    //        }
    //    }
    //}


