﻿namespace TradingCardsA3
{
    internal class DataSet
    {
    }
}