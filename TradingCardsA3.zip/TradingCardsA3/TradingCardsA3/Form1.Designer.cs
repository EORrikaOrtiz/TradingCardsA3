﻿namespace TradingCardsA3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonAddCard = new System.Windows.Forms.Button();
            this.buttonViewCard = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.labelTeam = new System.Windows.Forms.Label();
            this.labelStat1 = new System.Windows.Forms.Label();
            this.labelStat2 = new System.Windows.Forms.Label();
            this.panelCard = new System.Windows.Forms.Panel();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonAddCard
            // 
            this.buttonAddCard.Location = new System.Drawing.Point(39, 201);
            this.buttonAddCard.Name = "buttonAddCard";
            this.buttonAddCard.Size = new System.Drawing.Size(180, 75);
            this.buttonAddCard.TabIndex = 0;
            this.buttonAddCard.Text = "Add Card";
            this.buttonAddCard.UseVisualStyleBackColor = true;
            this.buttonAddCard.Click += new System.EventHandler(this.buttonAddCard_Click);
            // 
            // buttonViewCard
            // 
            this.buttonViewCard.Location = new System.Drawing.Point(39, 291);
            this.buttonViewCard.Name = "buttonViewCard";
            this.buttonViewCard.Size = new System.Drawing.Size(180, 75);
            this.buttonViewCard.TabIndex = 1;
            this.buttonViewCard.Text = "View Cards";
            this.buttonViewCard.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(278, 47);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(484, 354);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(390, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 146);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(330, 251);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(68, 25);
            this.labelName.TabIndex = 4;
            this.labelName.Text = "Name";
            // 
            // labelTeam
            // 
            this.labelTeam.AutoSize = true;
            this.labelTeam.Location = new System.Drawing.Point(332, 291);
            this.labelTeam.Name = "labelTeam";
            this.labelTeam.Size = new System.Drawing.Size(66, 25);
            this.labelTeam.TabIndex = 5;
            this.labelTeam.Text = "Team";
            // 
            // labelStat1
            // 
            this.labelStat1.AutoSize = true;
            this.labelStat1.Location = new System.Drawing.Point(334, 325);
            this.labelStat1.Name = "labelStat1";
            this.labelStat1.Size = new System.Drawing.Size(68, 25);
            this.labelStat1.TabIndex = 6;
            this.labelStat1.Text = "Stat 1";
            this.labelStat1.Click += new System.EventHandler(this.labelStat1_Click);
            // 
            // labelStat2
            // 
            this.labelStat2.AutoSize = true;
            this.labelStat2.Location = new System.Drawing.Point(334, 359);
            this.labelStat2.Name = "labelStat2";
            this.labelStat2.Size = new System.Drawing.Size(68, 25);
            this.labelStat2.TabIndex = 7;
            this.labelStat2.Text = "Stat 2";
            this.labelStat2.Click += new System.EventHandler(this.labelStat2_Click);
            // 
            // panelCard
            // 
            this.panelCard.Location = new System.Drawing.Point(472, 266);
            this.panelCard.Name = "panelCard";
            this.panelCard.Size = new System.Drawing.Size(200, 100);
            this.panelCard.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelCard);
            this.Controls.Add(this.labelStat2);
            this.Controls.Add(this.labelStat1);
            this.Controls.Add(this.labelTeam);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.buttonViewCard);
            this.Controls.Add(this.buttonAddCard);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAddCard;
        private System.Windows.Forms.Button buttonViewCard;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelTeam;
        private System.Windows.Forms.Label labelStat1;
        private System.Windows.Forms.Label labelStat2;
        private System.Windows.Forms.Panel panelCard;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.BindingSource bindingSource2;
    }
}

